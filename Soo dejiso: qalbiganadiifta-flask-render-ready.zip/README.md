
# Qalbiga Nadiifta

Blog Af-Soomaali ah oo ku saabsan xigmado, ducooyin, iyo ereyo qalbi taabanaya.  
Website-kan waxaa lagu dhisay HTML, CSS, iyo markdown (Jekyll format) si loogu daabaco GitHub Pages ama Netlify.

## Sida Loo Isticmaalo
- Ku raarso GitHub repo
- Ku xidho Netlify ama GitHub Pages
- Ku dar qoraallo cusub _posts/
